# EIC Modding — GitHub Pages

Includes a responsive dark blue/black website, animated cards, APK download buttons, tutorial pages, launcher links, and a Discord section.

## Publish using your iPhone

1. Download and extract `EIC-Modding-Website.zip` in the iPhone Files app.
2. At https://github.com, create a **Public** repository named `eic-modding`.
3. Upload the contents of this folder (not the outer folder itself). Ensure `index.html` is in the repository root. Upload the `tutorials` and `downloads` folders too.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then tap **Save**.
7. Wait a few minutes, then visit `https://YOUR-USERNAME.github.io/eic-modding/`.

## Configure links and downloads

- Replace `https://discord.gg/eic` in `index.html` with your actual Discord invite.
- Upload your APK files into `downloads/`. The button `downloads/StripesADB.apk` works only after that exact file is uploaded.
- Replace `downloads/your-file.apk` with the real path for your second APK.
- The Lightning Launcher button currently links to `https://threethan.itch.io/lightning-launcher`.
- Edit tutorial files in `tutorials/` to add your own steps.
- GitHub Pages is static hosting; it does not run server-side code. Published pages and files are publicly accessible.
